const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');

let users = [];

router.get('/', (req, res) => {
    if (req.session.user) return res.render('home', { user: req.session.user });
    res.redirect('/login');
});

router.get('/login', (req, res) => {
    res.render('auth/login');
});

router.post('/login', (req, res) => {
    const { email, password } = req.body;
    const user = users.find(u => u.email === email);
    if (user && bcrypt.compareSync(password, user.password)) {
        req.session.user = user;
        return res.redirect('/');
    }
    res.render('auth/login', { error: 'Credenciales incorrectas' });
});

router.get('/register', (req, res) => {
    res.render('auth/register');
});

router.post('/register', (req, res) => {
    const { name, email, password } = req.body;
    if (users.find(u => u.email === email)) {
        return res.render('auth/register', { error: 'El correo ya está registrado' });
    }
    const hashedPassword = bcrypt.hashSync(password, 10);
    users.push({ name, email, password: hashedPassword });
    res.redirect('/login');
});

router.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/login');
});

module.exports = router;